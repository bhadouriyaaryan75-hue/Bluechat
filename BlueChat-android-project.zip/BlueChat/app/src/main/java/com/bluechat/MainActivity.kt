package com.bluechat

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private lateinit var bt: BtChat
    private var askedPerm = false
    private var askedEnable = false

    private fun hasPerm() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bt = BtChat.get(this)
        setContent {
            App(bt, tick.intValue) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!hasPerm()) {
            if (!askedPerm) { askedPerm = true; requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1) }
            return
        }
        if (!bt.enabled()) {
            if (!askedEnable) { askedEnable = true; startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
            return
        }
        bt.listen()
        tick.intValue++
    }
}

class P(val bg: Color, val fg: Color, val mute: Color, val field: Color, val line: Color)

private val avColors = listOf(0xFFD62976, 0xFF4F5BD5, 0xFFFA7E1E, 0xFF962FBF, 0xFF0095F6)
private val blue = Color(0xFF0095F6)

@Composable
fun App(bt: BtChat, tick: Int, onPair: () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val p = if (dark) P(Color.Black, Color(0xFFF5F5F5), Color(0xFFA8A8A8), Color(0xFF262626), Color(0xFF262626))
            else P(Color.White, Color.Black, Color(0xFF737373), Color(0xFFEFEFEF), Color(0xFFDBDBDB))
    val devices = remember(tick) { bt.paired() }
    var open by remember { mutableStateOf<BluetoothDevice?>(null) }
    Surface(color = p.bg, modifier = Modifier.fillMaxSize()) {
        val d = open
        if (d == null) ListScreen(bt, devices, p, onPair) { open = it }
        else ChatScreen(bt, d, p) { open = null }
    }
}

@Composable
fun Avatar(d: BluetoothDevice, size: Int) {
    val c = Color(avColors[(d.address.hashCode() and 0x7fffffff) % avColors.size])
    Box(Modifier.size(size.dp).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text((d.name ?: "?").take(1).uppercase(), color = Color.White, fontSize = (size / 3).sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ListScreen(bt: BtChat, devices: List<BluetoothDevice>, p: P, onPair: () -> Unit, onOpen: (BluetoothDevice) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp, 8.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("bluechat", color = p.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(bt.status, color = p.mute, fontSize = 12.sp)
            }
            IconButton(onClick = onPair) { Icon(Icons.Default.Edit, "Pair device", tint = p.fg) }
        }
        LazyRow(contentPadding = PaddingValues(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(devices) { d ->
                Column(Modifier.width(70.dp).clickable { onOpen(d) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        Avatar(d, 64)
                        if (bt.connectedAddr == d.address)
                            Box(Modifier.align(Alignment.BottomEnd).size(16.dp).clip(CircleShape)
                                .background(Color(0xFF31A24C)).border(2.dp, p.bg, CircleShape))
                    }
                    Text(d.name ?: "?", color = p.mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Messages", color = p.fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Pair device", color = blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onPair() })
        }
        LazyColumn {
            items(devices) { d ->
                val last = bt.chats[d.address]?.lastOrNull()
                Row(Modifier.fillMaxWidth().clickable { onOpen(d) }.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(d, 56)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name ?: d.address, color = p.fg, fontSize = 14.sp)
                        Text(last?.let { (if (it.me) "You: " else "") + it.text + " · " + it.time } ?: "Tap to chat",
                            color = p.mute, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Icon(Icons.Default.CameraAlt, null, tint = p.mute)
                }
            }
            if (devices.isEmpty()) item {
                Text("Pehle Bluetooth settings mein dusre phone se pair karo (upar pencil dabao). Dono phones mein BlueChat install hona chahiye.",
                    color = p.mute, fontSize = 13.sp, modifier = Modifier.padding(24.dp))
            }
        }
    }
}

@Composable
fun ChatScreen(bt: BtChat, d: BluetoothDevice, p: P, onBack: () -> Unit) {
    LaunchedEffect(d.address) { bt.connect(d) }
    val msgs = bt.chats[d.address] ?: emptyList()
    val on = bt.connectedAddr == d.address
    var text by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(4.dp, 8.dp, 4.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = p.fg) }
            Avatar(d, 36)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name ?: d.address, color = p.fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(if (on) "Active now · Bluetooth" else bt.status, color = p.mute, fontSize = 12.sp, maxLines = 1)
            }
            Icon(Icons.Default.Call, null, tint = p.fg, modifier = Modifier.padding(8.dp))
            Icon(Icons.Default.Videocam, null, tint = p.fg, modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = ls,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            item {
                Column(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(d, 80)
                    Spacer(Modifier.height(8.dp))
                    Text(d.name ?: d.address, color = p.fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Bluetooth se connected, internet nahi chahiye", color = p.mute, fontSize = 13.sp)
                }
            }
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.me) Alignment.CenterEnd else Alignment.CenterStart) {
                    val shape = RoundedCornerShape(22.dp)
                    val base = Modifier.widthIn(max = 280.dp).clip(shape)
                    val mod = when {
                        m.failed -> base.border(1.dp, Color(0xFFED4956), shape)
                        m.me -> base.background(Brush.verticalGradient(listOf(Color(0xFFA033FF), Color(0xFF3D6BFF))))
                        else -> base.background(p.field)
                    }
                    Column(mod.padding(14.dp, 9.dp)) {
                        Text(m.text, fontSize = 15.sp,
                            color = if (m.failed) Color(0xFFED4956) else if (m.me) Color.White else p.fg)
                        if (m.failed) Text("Not sent", color = Color(0xFFED4956), fontSize = 11.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp, 8.dp).border(1.dp, p.line, RoundedCornerShape(24.dp)).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF0095F6), Color(0xFF6A5AF9)))),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = text, onValueChange = { text = it }, enabled = on,
                textStyle = TextStyle(color = p.fg, fontSize = 15.sp),
                cursorBrush = SolidColor(p.fg), modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) Text(if (on) "Message..." else "Connecting…", color = p.mute, fontSize = 15.sp)
                        inner()
                    }
                }
            )
            if (text.isNotBlank()) {
                TextButton(onClick = { bt.send(text.trim()); text = "" }) {
                    Text("Send", color = blue, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Icon(Icons.Default.Mic, null, tint = p.fg, modifier = Modifier.padding(6.dp))
                Icon(Icons.Default.Image, null, tint = p.fg, modifier = Modifier.padding(6.dp))
            }
        }
    }
}
