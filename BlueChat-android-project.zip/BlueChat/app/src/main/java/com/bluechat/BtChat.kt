package com.bluechat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.DataInputStream
import java.io.DataOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

data class Msg(val text: String, val me: Boolean, val time: String, val failed: Boolean = false)

@SuppressLint("MissingPermission")
class BtChat private constructor(ctx: Context) {
    companion object {
        @Volatile private var inst: BtChat? = null
        fun get(c: Context): BtChat = inst ?: BtChat(c.applicationContext).also { inst = it }
    }

    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val main = Handler(Looper.getMainLooper())
    private val uuid = UUID.fromString("8f1a2c3e-5b4d-4e6f-9a7b-0c1d2e3f4a5b")

    val chats = mutableStateMapOf<String, List<Msg>>()
    var status by mutableStateOf("Not connected")
    var connectedAddr by mutableStateOf<String?>(null)

    private var sock: BluetoothSocket? = null
    private var dout: DataOutputStream? = null
    private var listening = false

    fun enabled() = adapter?.isEnabled == true

    fun paired(): List<BluetoothDevice> =
        try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }

    private fun ui(f: () -> Unit) { main.post { f() } }
    private fun now(): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
    private fun add(addr: String, m: Msg) { chats[addr] = (chats[addr] ?: emptyList()) + m }

    // Dusre phone ke connection ka intezaar (server side)
    fun listen() {
        val a = adapter ?: return
        if (listening || !a.isEnabled) return
        listening = true
        thread {
            try {
                val srv = a.listenUsingRfcommWithServiceRecord("BlueChat", uuid)
                while (true) { attach(srv.accept()) }
            } catch (e: Exception) { }
            listening = false
        }
    }

    // Paired device se connect (client side)
    fun connect(d: BluetoothDevice) {
        if (connectedAddr == d.address) return
        ui { status = "Connecting to ${d.name}…" }
        thread {
            try {
                adapter?.cancelDiscovery()
                val s = d.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                attach(s)
            } catch (e: Exception) {
                ui { status = "Connect nahi hua. Dusre phone pe BlueChat khula rakho." }
            }
        }
    }

    private fun attach(s: BluetoothSocket) {
        try { sock?.close() } catch (_: Exception) { }
        sock = s
        val addr = s.remoteDevice.address
        val name = s.remoteDevice.name ?: addr
        dout = DataOutputStream(s.outputStream)
        ui { connectedAddr = addr; status = "Connected to $name" }
        thread {
            try {
                val din = DataInputStream(s.inputStream)
                while (true) {
                    val t = din.readUTF()
                    ui { add(addr, Msg(t, false, now())) }
                }
            } catch (e: Exception) { }
            ui { if (sock === s) { connectedAddr = null; status = "Disconnected" } }
        }
    }

    fun send(text: String) {
        val addr = connectedAddr ?: return
        val d = dout ?: return
        val m = Msg(text, true, now())
        add(addr, m)
        thread {
            try {
                synchronized(d) { d.writeUTF(text); d.flush() }
            } catch (e: Exception) {
                ui { chats[addr] = (chats[addr] ?: emptyList()).map { if (it === m) it.copy(failed = true) else it } }
            }
        }
    }
}
