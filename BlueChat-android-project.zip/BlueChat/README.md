# BlueChat: offline Bluetooth chat (Instagram-style UI)

## APK kaise banaye (Android Studio ke bina)
1. github.com pe free account banao, naya repository banao.
2. Is zip ke saare files repository mein upload karo (laptop se drag-drop sabse easy).
   `.github/workflows/build.yml` file bhi honi chahiye.
3. Repository > Actions tab > "Build APK" > Run workflow.
4. 5-8 minute baad run khologe to neeche "BlueChat-apk" milega. Download karo, zip kholo, app-debug.apk install karo
   (Settings mein "Install unknown apps" allow karna padega).

## Use kaise kare
1. Dono phones mein app install karo.
2. Phone Settings > Bluetooth se dono ko ek baar pair karo (ya app mein pencil icon dabao).
3. Dono phones mein BlueChat kholo. Ek phone pe dusre ka naam dabao: connect hoke chat khulegi.
4. Internet ya mobile data ki zaroorat nahi.

## Dhyan do
- Sirf Android. Range lagbhag 10 meter.
- Messages app band karne par save nahi rehte (abhi memory mein hain).
- Yeh code bhejne se pehle compile-test nahi hua. Build mein error aaye to error text bhej dena.
